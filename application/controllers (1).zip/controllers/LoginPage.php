<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginPage extends CI_Controller {

	public function index()
	{
		$this->load->view('loginPage');	
	}

}

/* End of file LoginPage.php */
/* Location: ./application/controllers/LoginPage.php */?>